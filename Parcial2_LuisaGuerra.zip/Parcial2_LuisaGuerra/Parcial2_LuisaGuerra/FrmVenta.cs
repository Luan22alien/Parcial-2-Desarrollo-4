﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    public partial class FrmVenta : Form
    {

        FarmaDB farmaciaObj = new FarmaDB();

        public FrmVenta()
        {
            InitializeComponent();
        }

        private void FrmVenta_Load(object sender, EventArgs e)
        {
            NpgsqlDataAdapter dataAdapter;
            DataTable dt = new DataTable();
            using (ConexionBD conexion = new ConexionBD())
            {
                conexion.conectar();
                if (conexion.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "SELECT id, nombre FROM productos_farmacia";
                        dataAdapter = new NpgsqlDataAdapter(sql, conexion.getMiConexion());
                        dataAdapter.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            cboMedicamento.DataSource = dt;
                            cboMedicamento.ValueMember = "id";
                            cboMedicamento.DisplayMember = "nombre";
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron medicamentos en la base de datos.");
                        }

                    }
                    catch (NpgsqlException ex)
                    {
                        MessageBox.Show("Error al consultar la Base Datos");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error de Conexion");
                    }
                }
            }
        }

        private void cboMedicamento_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMedicamento.SelectedValue != null && int.TryParse(cboMedicamento.SelectedValue.ToString(), out int id))
            {
                farmaciaObj.asignarId(id);
                DataTable dataTable = farmaciaObj.CargarInventario();

                if (dataTable.Rows.Count > 0)
                {
                    int stock = Convert.ToInt32(dataTable.Rows[0]["cantidad"]);
                    txtStock.Text = stock.ToString();
                }
                else
                {
                    txtStock.Text = "0";
                    MessageBox.Show("No se encontró el stock del medicamento seleccionado.");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtVender.Text, out int cantidadVenta) && cantidadVenta > 0)
            {
                if (int.TryParse(txtStock.Text, out int stockActual) && stockActual >= cantidadVenta)
                {
                    DataTable dataTable = farmaciaObj.CargarInventario();
                    decimal precioUnitario = Convert.ToDecimal(dataTable.Rows[0]["precio"]);

                    decimal totalCompra = cantidadVenta * precioUnitario;
                    decimal totalConIncremento = totalCompra * 1.07M;

                    if (farmaciaObj.ActualizarStock(-cantidadVenta))
                    {
                        MessageBox.Show($"Venta realizada con éxito.\nTotal: {totalConIncremento.ToString("C", CultureInfo.GetCultureInfo("en-US"))}");

                        txtStock.Text = (stockActual - cantidadVenta).ToString();
                    }
                    else
                    {
                        MessageBox.Show("Error al realizar la venta.");
                    }
                }
                else
                {
                    MessageBox.Show("Stock insuficiente para la venta.");
                }
            }
            else
            {
                MessageBox.Show("Ingrese una cantidad válida para vender.");
            }
        }

        private void txtVender_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
