﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    public partial class FrmNuevoMedicamento : Form
    {

        FarmaDB farmaciaObj = new FarmaDB();
        private byte[] imagenByteArray;

        public FrmNuevoMedicamento()
        {
            InitializeComponent();
        }

        private void btnCargarImagen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Imagenes|*.jpg;*.jpeg;*.png;"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string rutaImagen = openFileDialog.FileName;
                imagenByteArray = File.ReadAllBytes(rutaImagen);
                pbFoto.Image = Image.FromFile(rutaImagen);
            }
        }

        private void btnAñadirMedicamento_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            if (decimal.TryParse(txtPrecio.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal precio) && int.TryParse(txtUnidades.Text, out int unidades) && imagenByteArray != null)
            {
                if (!farmaciaObj.ExisteMedicamento(nombre))
                {
                    bool exito = farmaciaObj.InsertarMedicamento(nombre, precio, unidades, imagenByteArray);

                    if (exito)
                    {
                        MessageBox.Show("Se añadió nuevo medicamento al inventario.");
                    }
                    else
                    {
                        MessageBox.Show("Error al añadir el medicamento.");
                    }
                }
                else
                {
                    MessageBox.Show("Ya existe un medicamento con ese nombre.");
                }
            }
            else
            {
                MessageBox.Show("Complete todos los campos correctamente e incluya una imagen.");
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
            else if (e.KeyChar == '.' && textBox.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txtUnidades_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmNuevoMedicamento_Load(object sender, EventArgs e)
        {

        }
    }
}
