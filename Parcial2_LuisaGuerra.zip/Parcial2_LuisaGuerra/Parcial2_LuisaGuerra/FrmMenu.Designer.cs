﻿namespace Parcial2_LuisaGuerra
{
    partial class FrmMenu
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.problema1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraGraficaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.problema2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.farmaciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inventarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarInventarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventaDeMedicamentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarNuevoMedicamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.problema1ToolStripMenuItem,
            this.problema2ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1067, 40);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // problema1ToolStripMenuItem
            // 
            this.problema1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculadoraGraficaToolStripMenuItem});
            this.problema1ToolStripMenuItem.Name = "problema1ToolStripMenuItem";
            this.problema1ToolStripMenuItem.Size = new System.Drawing.Size(149, 36);
            this.problema1ToolStripMenuItem.Text = "Problema 1";
            // 
            // calculadoraGraficaToolStripMenuItem
            // 
            this.calculadoraGraficaToolStripMenuItem.Name = "calculadoraGraficaToolStripMenuItem";
            this.calculadoraGraficaToolStripMenuItem.Size = new System.Drawing.Size(306, 36);
            this.calculadoraGraficaToolStripMenuItem.Text = "Calculadora Grafica";
            this.calculadoraGraficaToolStripMenuItem.Click += new System.EventHandler(this.calculadoraGraficaToolStripMenuItem_Click);
            // 
            // problema2ToolStripMenuItem
            // 
            this.problema2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.farmaciaToolStripMenuItem});
            this.problema2ToolStripMenuItem.Name = "problema2ToolStripMenuItem";
            this.problema2ToolStripMenuItem.Size = new System.Drawing.Size(149, 36);
            this.problema2ToolStripMenuItem.Text = "Problema 2";
            // 
            // farmaciaToolStripMenuItem
            // 
            this.farmaciaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inventarioToolStripMenuItem,
            this.editarInventarioToolStripMenuItem,
            this.ventaDeMedicamentosToolStripMenuItem,
            this.agregarNuevoMedicamentoToolStripMenuItem});
            this.farmaciaToolStripMenuItem.Name = "farmaciaToolStripMenuItem";
            this.farmaciaToolStripMenuItem.Size = new System.Drawing.Size(195, 36);
            this.farmaciaToolStripMenuItem.Text = "Farmacia";
            // 
            // inventarioToolStripMenuItem
            // 
            this.inventarioToolStripMenuItem.Name = "inventarioToolStripMenuItem";
            this.inventarioToolStripMenuItem.Size = new System.Drawing.Size(415, 36);
            this.inventarioToolStripMenuItem.Text = "Inventario";
            this.inventarioToolStripMenuItem.Click += new System.EventHandler(this.inventarioToolStripMenuItem_Click);
            // 
            // editarInventarioToolStripMenuItem
            // 
            this.editarInventarioToolStripMenuItem.Name = "editarInventarioToolStripMenuItem";
            this.editarInventarioToolStripMenuItem.Size = new System.Drawing.Size(415, 36);
            this.editarInventarioToolStripMenuItem.Text = "Editar Inventario";
            this.editarInventarioToolStripMenuItem.Click += new System.EventHandler(this.editarInventarioToolStripMenuItem_Click);
            // 
            // ventaDeMedicamentosToolStripMenuItem
            // 
            this.ventaDeMedicamentosToolStripMenuItem.Name = "ventaDeMedicamentosToolStripMenuItem";
            this.ventaDeMedicamentosToolStripMenuItem.Size = new System.Drawing.Size(415, 36);
            this.ventaDeMedicamentosToolStripMenuItem.Text = "Venta de medicamentos";
            this.ventaDeMedicamentosToolStripMenuItem.Click += new System.EventHandler(this.ventaDeMedicamentosToolStripMenuItem_Click);
            // 
            // agregarNuevoMedicamentoToolStripMenuItem
            // 
            this.agregarNuevoMedicamentoToolStripMenuItem.Name = "agregarNuevoMedicamentoToolStripMenuItem";
            this.agregarNuevoMedicamentoToolStripMenuItem.Size = new System.Drawing.Size(415, 36);
            this.agregarNuevoMedicamentoToolStripMenuItem.Text = "Agregar nuevo Medicamento";
            this.agregarNuevoMedicamentoToolStripMenuItem.Click += new System.EventHandler(this.agregarNuevoMedicamentoToolStripMenuItem_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmMenu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.FrmMenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem problema1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem problema2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem farmaciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inventarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventaDeMedicamentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarNuevoMedicamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraGraficaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarInventarioToolStripMenuItem;
    }
}

