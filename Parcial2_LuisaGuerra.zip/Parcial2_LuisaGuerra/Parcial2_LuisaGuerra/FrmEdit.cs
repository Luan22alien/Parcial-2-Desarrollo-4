﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    public partial class FrmEdit : Form
    {

        FarmaDB farmaciaObj = new FarmaDB();
        public FrmEdit()
        {
            InitializeComponent();
        }

        private void FrmEdit_Load(object sender, EventArgs e)
        {
            NpgsqlDataAdapter dataAdapter;
            DataTable dt = new DataTable();
            using (ConexionBD conexion = new ConexionBD())
            {
                conexion.conectar();
                if (conexion.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "SELECT id, nombre FROM productos_farmacia";
                        dataAdapter = new NpgsqlDataAdapter(sql, conexion.getMiConexion());
                        dataAdapter.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            cboMedicamento.DataSource = dt;
                            cboMedicamento.ValueMember = "id";
                            cboMedicamento.DisplayMember = "nombre";
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron medicamentos en la base de datos.");
                        }

                    }
                    catch (NpgsqlException ex)
                    {
                        MessageBox.Show("Error al consultar la Base Datos");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error de Conexion");
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cboMedicamento.SelectedValue != null && int.TryParse(cboMedicamento.SelectedValue.ToString(), out int id))
            {
                string nuevoNombre = txtNombre.Text.Trim();
                bool cambiarPrecio = decimal.TryParse(txtPrecio.Text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal nuevoPrecio);
                bool cambiarCantidad = int.TryParse(txtStock.Text, out int nuevaCantidad);

                bool exito = farmaciaObj.editarMedicamento(id, nuevoNombre, cambiarPrecio ? (decimal?)nuevoPrecio : null, cambiarCantidad ? (int?)nuevaCantidad : null);

                if (exito)
                {
                    MessageBox.Show("El medicamento ha sido actualizado exitosamente.");
                }
                else
                {
                    MessageBox.Show("Error al actualizar el medicamento.");
                }
            }
            else
            {
                MessageBox.Show("Seleccione un medicamento válido.");
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
            else if (e.KeyChar == '.' && textBox.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txtStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }
    }
}
