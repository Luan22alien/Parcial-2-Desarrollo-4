﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    internal class FarmaDB
    {
        private int id;

        public void asignarId(int id)
        {
            this.id = id;
        }

        public DataTable CargarInventario()
        {
            DataTable dt = new DataTable();

            using (ConexionBD conexionBD = new ConexionBD())
            {
                conexionBD.conectar();
                if (conexionBD.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "SELECT nombre, cantidad, precio FROM productos_farmacia WHERE id = @id";
                        using (NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(sql, conexionBD.getMiConexion()))
                        {
                            dataAdapter.SelectCommand.Parameters.AddWithValue("@id", id);
                            dataAdapter.Fill(dt);
                        }
                    } 
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al consultar la base de datos: {ex.Message}");
                    }
                }
                else
                {
                    MessageBox.Show("No se pudo conectar a la base de datos.");
                }
            }
            return dt;
        }

        public bool ActualizarStock(int cantidad)
        {
            using (ConexionBD conexionBD = new ConexionBD())
            {
                conexionBD.conectar();
                if (conexionBD.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "UPDATE productos_farmacia SET cantidad = cantidad + @cantidad WHERE id = @id";
                        using (NpgsqlCommand cmd = new NpgsqlCommand(sql, conexionBD.getMiConexion()))
                        {
                            cmd.Parameters.AddWithValue("@cantidad", cantidad);
                            cmd.Parameters.AddWithValue("@id", id);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            return true;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al actualizar el stock: {ex.Message}");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("No se pudo conectar a la base de datos.");
                    return false;
                }
            }
        }

        public bool ExisteMedicamento(string nombre)
        {
            bool existe = false;
            using (ConexionBD conexion = new ConexionBD())
            {
                conexion.conectar();
                if (conexion.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "SELECT COUNT(*) FROM productos_farmacia WHERE nombre ILIKE @nombre";
                        using (NpgsqlCommand cmd = new NpgsqlCommand(sql, conexion.getMiConexion()))
                        {
                            cmd.Parameters.AddWithValue("@nombre", nombre);
                            int count = Convert.ToInt32(cmd.ExecuteScalar());
                            existe = count > 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al verificar el medicamento: {ex.Message}");
                    }
                }
            }
            return existe;
        }

        public bool InsertarMedicamento(string nombre, decimal precio, int unidades, byte[] imagen)
        {
            bool exito = false;
            using (ConexionBD conexion = new ConexionBD())
            {
                conexion.conectar();
                if (conexion.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "INSERT INTO productos_farmacia (nombre, cantidad, precio, imagen) VALUES (@nombre, @cantidad, @precio, @imagen)";
                        using (NpgsqlCommand cmd = new NpgsqlCommand(sql, conexion.getMiConexion()))
                        {
                            cmd.Parameters.AddWithValue("@nombre", nombre);
                            cmd.Parameters.AddWithValue("@cantidad", unidades);
                            cmd.Parameters.AddWithValue("@precio", precio);
                            cmd.Parameters.AddWithValue("@imagen", imagen);

                            exito = cmd.ExecuteNonQuery() > 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al insertar el medicamento: {ex.Message}");
                    }
                }
            }
            return exito;
        }

        public bool editarMedicamento(int id, string nuevoNombre, decimal? nuevoPrecio, int? nuevaCantidad)
        {
            bool exito = false;
            using (ConexionBD conexion = new ConexionBD())
            {
                conexion.conectar();
                if (conexion.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "UPDATE productos_farmacia SET ";
                        var parametros = new List<NpgsqlParameter>();

                        if (!string.IsNullOrEmpty(nuevoNombre))
                        {
                            sql += "nombre = @nombre, ";
                            parametros.Add(new NpgsqlParameter("@nombre", nuevoNombre));
                        }
                        if (nuevoPrecio.HasValue)
                        {
                            sql += "precio = @precio, ";
                            parametros.Add(new NpgsqlParameter("@precio", nuevoPrecio.Value));
                        }
                        if (nuevaCantidad.HasValue)
                        {
                            sql += "cantidad = @cantidad, ";
                            parametros.Add(new NpgsqlParameter("@cantidad", nuevaCantidad.Value));
                        }

                        sql = sql.TrimEnd(',', ' ') + " WHERE id = @id";
                        parametros.Add(new NpgsqlParameter("@id", id));

                        using (NpgsqlCommand cmd = new NpgsqlCommand(sql, conexion.getMiConexion()))
                        {
                            cmd.Parameters.AddRange(parametros.ToArray());
                            exito = cmd.ExecuteNonQuery() > 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al actualizar el medicamento: {ex.Message}");
                    }
                }
            }
            return exito;
        }
    }

}
