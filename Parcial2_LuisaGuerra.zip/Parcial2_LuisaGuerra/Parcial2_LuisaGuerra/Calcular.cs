﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    internal class Calcular
    {
        private double variableX2 = 0;
        private double variableX1 = 0;
        private double variableC = 0;

        private double variableM = 0;
        private double variableB = 0;

        public void asignarCuadratica(double x2, double x1, double c)
        {
            variableC = c;
            variableX2 = x2;
            variableX1 = x1;
        }

        public void asignarLineal(double m, double b)
        {
            variableM = m;
            variableB = b;
        }

        public List<PointF> calcularCuadratica()
        {
            List<PointF> puntos = new List<PointF>();

            for (double x = -10; x <= 10; x += 0.5)
            {
                double y = (variableX2 * x * x) + (variableX1 * x) + variableC;
                puntos.Add(new PointF((float)x, (float)y));
            }

            double discriminante = (variableX1 * variableX1) - (4 * variableX2 * variableC);
            if (discriminante < 0)
            {
                MessageBox.Show("La función cuadrática no tiene raíces reales.", "Sin raíces reales");
            }
            else if (discriminante == 0)
            {
                double raiz = -variableX1 / (2 * variableX2);
                puntos.Add(new PointF((float)raiz, 0));
                MessageBox.Show($"La función cuadrática tiene una raíz doble en x = {raiz}.", "Raíz doble");
            }
            else
            {
                double raiz1 = (-variableX1 + Math.Sqrt(discriminante)) / (2 * variableX2);
                double raiz2 = (-variableX1 - Math.Sqrt(discriminante)) / (2 * variableX2);
                puntos.Add(new PointF((float)raiz1, 0));
                puntos.Add(new PointF((float)raiz2, 0));
                MessageBox.Show($"Las raíces de la función cuadrática son:\nRaiz 1 = {raiz1}\nRaiz2 = {raiz2}", "Raíces");
            }

            return puntos;
        }

        public List<PointF> calcularLineal()
        {
            List<PointF> puntos = new List<PointF>();

            for (double x = -10; x <= 10; x += 5)
            {
                double y = variableM * x + variableB;
                puntos.Add(new PointF((float)x, (float)y));
            }

            double xInterseccion = -variableB / variableM;
            puntos.Add(new PointF((float)xInterseccion, 0));
            MessageBox.Show($"La intersección de la línea con el eje X es en x = {xInterseccion}, y = 0.", "Intersección");

            return puntos;
        }
    }
}
