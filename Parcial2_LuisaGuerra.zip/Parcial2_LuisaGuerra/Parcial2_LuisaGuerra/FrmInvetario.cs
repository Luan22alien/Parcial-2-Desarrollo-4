﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    public partial class FrmInvetario : Form
    {
        FarmaDB farmaciaObj = new FarmaDB();
        public FrmInvetario()
        {
            InitializeComponent();
        }

        private void FrmInvetario_Load(object sender, EventArgs e)
        {
            NpgsqlDataAdapter dataAdapter;
            DataTable dt = new DataTable();
            using (ConexionBD conexion = new ConexionBD())
            {
                conexion.conectar();
                if (conexion.getMiConexion().State == ConnectionState.Open)
                {
                    try
                    {
                        string sql = "SELECT id, nombre FROM productos_farmacia";
                        dataAdapter = new NpgsqlDataAdapter(sql, conexion.getMiConexion());
                        dataAdapter.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            cboMedicamento.DataSource = dt;
                            cboMedicamento.ValueMember = "id";
                            cboMedicamento.DisplayMember = "nombre";
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron medicamentos en la base de datos.");
                        }

                    }
                    catch (NpgsqlException ex)
                    {
                        MessageBox.Show("Error al consultar la Base Datos");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error de Conexion");
                    }
                }
            }
        }

        private void cboMedicamento_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                if (cboMedicamento.SelectedValue != null && int.TryParse(cboMedicamento.SelectedValue.ToString(), out int id))
                {
                    farmaciaObj.asignarId(id);
                    DataTable dataTable = new DataTable();
                    dataTable = farmaciaObj.CargarInventario();

                    if (dataTable.Rows.Count > 0)
                    {
                        dgvInvetario.DataSource = dataTable;
                    }
                    else
                    {
                        MessageBox.Show("No se encontraron detalles para el medicamento seleccionado.");
                    }
                }
            
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtAdd.Text, out int cantidad) && cantidad > 0)
            {
                if (farmaciaObj.ActualizarStock(cantidad))
                {
                    MessageBox.Show("Stock actualizado exitosamente.");
                    dgvInvetario.DataSource = farmaciaObj.CargarInventario();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el stock.");
                }
            }
            else
            {
                MessageBox.Show("Ingrese una cantidad válida.");
            }
        }

        private void txtAdd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }
    }
}
