﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    public partial class FrmProblema1 : Form
    {
        public FrmProblema1()
        {
            InitializeComponent();
        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtX2.Text, out double x2) && double.TryParse(txtX1.Text, out double x1) && double.TryParse(txtC.Text, out double c))
            {
                Calcular calcularObj = new Calcular();
                calcularObj.asignarCuadratica(x2, x1, c);

                List<PointF> puntosCuadratica = calcularObj.calcularCuadratica();

                DibujarGrafica(puntosCuadratica);
            }
        }

        private void btnEjecutarLineal_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtB.Text, out double b) && double.TryParse(txtM.Text, out double m))
            {
                Calcular calcularObj2 = new Calcular();
                calcularObj2.asignarLineal(m, b);

                List<PointF> puntosLineales = calcularObj2.calcularLineal();

                DibujarGrafica(puntosLineales);
            }
        }

        private void DibujarGrafica(List<PointF> puntos)
        {
            Bitmap bmp = new Bitmap(pbGrafica.Width, pbGrafica.Height);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.White);
                int centerX = pbGrafica.Width / 2;
                int centerY = pbGrafica.Height / 2;
                int scale = 18;

                g.DrawLine(Pens.Black, 0, centerY, pbGrafica.Width, centerY);
                g.DrawLine(Pens.Black, centerX, 0, centerX, pbGrafica.Height);

                for (int i = -15; i <= 15; i++)
                {
                    int x = centerX + i * scale;
                    g.DrawLine(Pens.Gray, x, centerY - 5, x, centerY + 5);
                    g.DrawString(i.ToString(), new Font("Arial", 8), Brushes.Black, x - 10, centerY + 5);
                }

                for (int i = -15; i <= 15; i++)
                {
                    int y = centerY - i * scale;
                    g.DrawLine(Pens.Gray, centerX - 5, y, centerX + 5, y);
                    g.DrawString(i.ToString(), new Font("Arial", 8), Brushes.Black, centerX + 5, y - 10);
                }

                for (int i = 0; i < puntos.Count; i++)
                {
                    int x = centerX + (int)(puntos[i].X * scale);
                    int y = centerY - (int)(puntos[i].Y * scale);
                    g.FillEllipse(Brushes.Red, x - 3, y - 3, 6, 6);

                    if (i > 0)
                    {
                        int prevX = centerX + (int)(puntos[i - 1].X * scale);
                        int prevY = centerY - (int)(puntos[i - 1].Y * scale);
                        g.DrawLine(Pens.Blue, prevX, prevY, x, y);
                    }
                }
            }
            pbGrafica.Image = bmp;
        }

        private void validarEntrada(object sender, KeyPressEventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '+' && e.KeyChar != '-' && e.KeyChar != '\b')
            {
                e.Handled = true;
            } 
            else if ((e.KeyChar == '+' || e.KeyChar == '-') &&
                     (textBox.SelectionStart != 0 || textBox.Text.Contains("+") || textBox.Text.Contains("-")))
            {
                e.Handled = true;
            }
            else if (e.KeyChar == '.' && textBox.Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void txtX2_KeyPress(object sender, KeyPressEventArgs e)
        {
            validarEntrada(sender, e);
        }

        private void txtX1_KeyPress(object sender, KeyPressEventArgs e)
        {
            validarEntrada(sender, e);
        }

        private void txtC_KeyPress(object sender, KeyPressEventArgs e)
        {
            validarEntrada(sender, e);
        }

        private void txtM_KeyPress(object sender, KeyPressEventArgs e)
        {
            validarEntrada(sender, e);
        }

        private void txtB_KeyPress(object sender, KeyPressEventArgs e)
        {
            validarEntrada(sender, e);
        }

        private void FrmProblema1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
