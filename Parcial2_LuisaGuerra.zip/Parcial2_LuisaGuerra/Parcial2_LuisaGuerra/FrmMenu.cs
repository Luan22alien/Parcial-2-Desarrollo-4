﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcial2_LuisaGuerra
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void calculadoraGraficaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProblema1 problema1Obj = new FrmProblema1();
            problema1Obj.MdiParent = this;
            problema1Obj.WindowState = FormWindowState.Maximized;
            problema1Obj.Show();
        }

        private void inventarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmInvetario inventarioObj = new FrmInvetario();
            inventarioObj.MdiParent = this;
            inventarioObj.WindowState = FormWindowState.Maximized;
            inventarioObj.Show();
        }

        private void ventaDeMedicamentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmVenta VenderoObj = new FrmVenta();
            VenderoObj.MdiParent = this;
            VenderoObj.WindowState = FormWindowState.Maximized;
            VenderoObj.Show();
        }

        private void agregarNuevoMedicamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevoMedicamento medObj = new FrmNuevoMedicamento();
            medObj.MdiParent = this;
            medObj.WindowState = FormWindowState.Maximized;
            medObj.Show();
        }

        private void editarInventarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEdit editarObj = new FrmEdit();
            editarObj.MdiParent = this;
            editarObj.WindowState = FormWindowState.Maximized;
            editarObj.Show();
        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
