﻿namespace Parcial2_LuisaGuerra
{
    partial class FrmInvetario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvInvetario = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cboMedicamento = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.pnlInvt = new System.Windows.Forms.Panel();
            this.btnCargar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvetario)).BeginInit();
            this.pnlInvt.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvInvetario
            // 
            this.dgvInvetario.AllowUserToAddRows = false;
            this.dgvInvetario.AllowUserToDeleteRows = false;
            this.dgvInvetario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInvetario.Location = new System.Drawing.Point(63, 166);
            this.dgvInvetario.Margin = new System.Windows.Forms.Padding(4);
            this.dgvInvetario.Name = "dgvInvetario";
            this.dgvInvetario.ReadOnly = true;
            this.dgvInvetario.RowHeadersWidth = 51;
            this.dgvInvetario.Size = new System.Drawing.Size(597, 294);
            this.dgvInvetario.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(113, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Medicamento: ";
            // 
            // cboMedicamento
            // 
            this.cboMedicamento.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboMedicamento.FormattingEnabled = true;
            this.cboMedicamento.Location = new System.Drawing.Point(273, 25);
            this.cboMedicamento.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboMedicamento.Name = "cboMedicamento";
            this.cboMedicamento.Size = new System.Drawing.Size(365, 39);
            this.cboMedicamento.TabIndex = 18;
            this.cboMedicamento.SelectedIndexChanged += new System.EventHandler(this.cboMedicamento_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(57, 95);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 29);
            this.label2.TabIndex = 19;
            this.label2.Text = "Agregar al Inventario:";
            // 
            // txtAdd
            // 
            this.txtAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdd.Location = new System.Drawing.Point(273, 90);
            this.txtAdd.Margin = new System.Windows.Forms.Padding(4);
            this.txtAdd.Multiline = true;
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(188, 38);
            this.txtAdd.TabIndex = 20;
            this.txtAdd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdd_KeyPress);
            // 
            // pnlInvt
            // 
            this.pnlInvt.Controls.Add(this.btnCargar);
            this.pnlInvt.Controls.Add(this.txtAdd);
            this.pnlInvt.Controls.Add(this.label2);
            this.pnlInvt.Controls.Add(this.cboMedicamento);
            this.pnlInvt.Controls.Add(this.label1);
            this.pnlInvt.Controls.Add(this.dgvInvetario);
            this.pnlInvt.Location = new System.Drawing.Point(185, 100);
            this.pnlInvt.Margin = new System.Windows.Forms.Padding(4);
            this.pnlInvt.Name = "pnlInvt";
            this.pnlInvt.Size = new System.Drawing.Size(725, 517);
            this.pnlInvt.TabIndex = 21;
            // 
            // btnCargar
            // 
            this.btnCargar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCargar.Location = new System.Drawing.Point(476, 90);
            this.btnCargar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCargar.Name = "btnCargar";
            this.btnCargar.Size = new System.Drawing.Size(164, 39);
            this.btnCargar.TabIndex = 21;
            this.btnCargar.Text = "Agregar";
            this.btnCargar.UseVisualStyleBackColor = true;
            this.btnCargar.Click += new System.EventHandler(this.btnCargar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DimGray;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(454, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 45);
            this.label3.TabIndex = 22;
            this.label3.Text = "Inventario\r\n";
            // 
            // FrmInvetario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Parcial2_LuisaGuerra.Properties.Resources.Mentafetaminas;
            this.ClientSize = new System.Drawing.Size(1099, 672);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pnlInvt);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmInvetario";
            this.Text = "m";
            this.Load += new System.EventHandler(this.FrmInvetario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvetario)).EndInit();
            this.pnlInvt.ResumeLayout(false);
            this.pnlInvt.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvInvetario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboMedicamento;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Panel pnlInvt;
        private System.Windows.Forms.Button btnCargar;
        private System.Windows.Forms.Label label3;
    }
}